#include<stdio.h>
//#include"somefile.h"
extern int i=10;/*//witout including header file this will compile ow redefiniti		on error will compile*/
//i=7;
//i=7+45;
 void main(){
 //;
printf("i=%d",i);
}
