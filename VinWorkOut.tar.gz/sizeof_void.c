#include <stdio.h>
int main(){
 
  printf("sizeof void*=%d\t sizeof int*=%d\n",sizeof(void *),sizeof(int *));

}
