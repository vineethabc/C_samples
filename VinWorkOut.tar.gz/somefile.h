#ifndef somefile_h
#define somefile_h
#endif

int i=25;
