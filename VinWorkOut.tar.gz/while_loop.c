#include<stdio.h>
#include<stdlib.h>
int main(){

int i=0,j=10;

while(i<10 ||  (4<j&&j<15)){
 printf("%d\t",i);
 i++;j++;
}

return 0;
}
