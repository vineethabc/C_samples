#include <stdio.h>
int main(){
 int i=5,j,sum;
 j=(++i)+(++i);
 sum=5+-3+6;
 printf("j=%d i=%d sum=%d",j,i,sum);

}
