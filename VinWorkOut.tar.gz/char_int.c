#include <stdio.h>
#include <stdlib.h>
//#include <string.h>

void main(){
 int a;
//char b;
while(1){
printf("\nEnter the no?\n");
scanf("%d",&a);
printf("\t ==%c",(char)a);
}


}
