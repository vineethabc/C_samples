# C_samples
C sample questions and Programs for interviews
