#include<stdio.h>
main(){
 char a='B';
 int k=67;
 printf("%ld\n",sizeof(a));
 printf("%ld\n",sizeof('B'));
 printf("%ld\n",sizeof(!k));
 printf("%lf\n", sizeof(!5));


}
